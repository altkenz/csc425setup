package edu.murraystate.csc425.setup;

public class Application {
  public static void main(final String ... args){
    final Hello hello = new Hello();
    System.out.println(hello.hello());
  }
}
