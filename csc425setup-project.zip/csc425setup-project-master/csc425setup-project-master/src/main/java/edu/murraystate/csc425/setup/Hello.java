package edu.murraystate.csc425.setup;

public class Hello {
  public String hello(){
    return ("hello");
  }
}
